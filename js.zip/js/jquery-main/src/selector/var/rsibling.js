export default /[+~]/;
