import pseudos from "./pseudos.js";

export default new RegExp( pseudos );
