export default "checked|selected|async|autofocus|autoplay|controls|defer|disabled|hidden|ismap|" +
	"loop|multiple|open|readonly|required|scoped";
