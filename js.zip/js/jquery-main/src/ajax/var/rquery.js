export default ( /\?/ );
