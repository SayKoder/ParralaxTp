import hasOwn from "./hasOwn.js";

export default hasOwn.toString;
